```markdown
# Project History & Timeline

Owner: @VisionQantech  
Project start: 2015  
Status: Active (2025) — 10+ years of continuous work

Summary:
This document records the high-level milestones and focus shifts over the project's lifetime. It is intended to document progress, acknowledge contributors, and help with reproducibility and reporting.

Timeline & milestones
- 2015 — Project founded
  - Initial idea, research questions, and goals defined.
  - Early prototyping and literature review.

- 2016–2018 — Prototyping and data collection
  - Built first toy models and notebooks.
  - Collected synthetic and small curated datasets for experiments.

- 2019–2020 — Shift toward safety & interpretability
  - Began focusing on alignment, interpretability experiments, and minimal safe prototypes.
  - Developed first reproducible small-model experiments.

- 2021–2022 — Infrastructure & reproducibility
  - Created experiment runners, logging, and seeded training pipelines.
  - Added safety checklist and basic evaluation harnesses.

- 2023–2024 — Roadmap refinement & community engagement
  - Drafted multi-year roadmap for interpretability and scalable oversight.
  - Started documentation and CI scaffolding for reproducible sharing.

- 2025 — Current status (10-year mark)
  - Repository scaffolded for safety-first research.
  - Focus for next phase: systematic mechanistic probes, scalable oversight experiments in toy settings, robust evaluation suite, and formal internal safety reviews before any release.

Acknowledgements & contributors
- Owner: @VisionQantech
- Contributors / collaborators: (list names / GitHub handles as appropriate)

Notes
- This repo emphasizes small-scale, reproducible experiments and strict safety review before any model/weights release.
- To add a milestone: please open an issue or a pull request with details, date, and any artifacts (papers, notebooks, logs).
```