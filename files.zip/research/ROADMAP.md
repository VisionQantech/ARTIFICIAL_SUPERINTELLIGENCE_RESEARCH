```markdown
# 12-Month Research Roadmap (starter)

Focus: interpretability + scalable oversight on small models (safety-first).

Months 0–2
- Reproducible infra: experiment runner, requirements, small toy models.
- Select 2–3 focused research questions.

Months 3–5
- Mechanistic probes on toy models (circuit motifs).
- Small evaluation harnesses and logging.

Months 6–8
- Baseline scalable oversight experiments (amplification / distillation variants in toy tasks).
- Robustness tests under distribution shift.

Months 9–11
- Multi-agent simulation experiments and stress tests.
- Prepare reproducible draft and internal safety audit.

Month 12
- Finalize reproducible artifacts, internal red-team, and release plan (if safe).
```