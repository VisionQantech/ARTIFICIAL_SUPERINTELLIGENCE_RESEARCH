```markdown
## About / History

Started in 2015 — maintained continuously through 2025 (10+ years).  
This repository represents long-term, safety-first research into interpretability, scalable oversight, and robustness for advanced AI systems. See HISTORY.md for a year-by-year timeline of milestones and progress.
```