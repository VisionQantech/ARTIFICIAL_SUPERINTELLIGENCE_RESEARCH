```markdown
# Evaluation Checklist

- Reproducibility
  - Seeds, env, package versions logged
  - Config files saved

- Behavior
  - Calibration, confidence, and failure modes assessed
  - Adversarial/dist-shift tests

- Interpretability
  - Activation logs, attention maps saved
  - Unit tests for interpretability scripts

- Safety
  - Red-team scenarios defined
  - No sensitive data used
```