```markdown
# SAFETY.md

This repository follows a safety-first approach. Before running, publishing, or scaling any experiment, follow this checklist.

1. Purpose & Scope
   - Define the exact research question.
   - Identify potential dual-use risks and document mitigations.

2. Minimality
   - Prefer minimal toy settings (small models, synthetic data) for initial experiments.

3. Access Control
   - Keep experiments and logs private until a safety review.
   - Do not add API keys or real-sensitive datasets to the repo.

4. Reproducibility & Audit
   - Record seeds, versions, and exact configs for each run.
   - Save deterministic evaluation scripts and raw logs.

5. Evaluation & Red-team
   - Create failure-mode tests (adversarial / distribution shift).
   - Run a red-team review before any public release.

6. Release Policy
   - No public release of model weights or scaling recipes without multi-party safety sign-off.

7. Contact & Incident Response
   - Owner: @VisionQantech
   - If you find a serious safety issue, create a private issue and tag 'security' and 'safety'.
```